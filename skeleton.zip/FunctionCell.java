class FunctionCell extends Cell {
    //TODO add some other methods if necessary
    
}

class ParkCell extends FunctionCell {
    //TODO add some other methods if necessary
}

class GotoJailCell extends FunctionCell {
    //TODO add some other methods if necessary
}

